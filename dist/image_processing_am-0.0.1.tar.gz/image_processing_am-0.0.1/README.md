# image_processing_am

Description. 
The package image_processing_am is used to:
	Processing:
		- Histrogram matching
		- Strutructural similarity
		- Resize image

	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing_am
```

## Author
Anderson

## License
[MIT](https://choosealicense.com/licenses/mit/)